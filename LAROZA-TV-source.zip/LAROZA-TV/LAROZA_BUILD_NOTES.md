# LAROZA TV – customized Luna Browser source

Changes made:
- Launcher name changed to LAROZA TV.
- Application ID changed to tv.laroza.browser.
- App opens https://laroza-tv.lat/home.24 on launch (after profile/PIN gating).
- Existing Luna HTML5 fullscreen video controls, remote controls, popup guards and adblock lists are retained.

Important:
- This is source code, not a compiled APK.
- The original project already contains fullscreen controls for HTML5 video and ad/pop-up blocking.
- Fullscreen/landscape behavior depends on the website's player and Android WebView; embedded or DRM/proprietary players may behave differently.
- No claim that every ad is blocked: first-party/server-inserted ads can remain.
- Build with Android Studio, JDK 17, Android SDK 36, and network access to download Gradle dependencies.
- Open the project folder in Android Studio and build the `app` release variant.
