# LAROZA TV – customized Luna Browser source

Changes made:
- Launcher name changed to LAROZA TV.
- Application ID changed to tv.laroza.browser.
- App opens https://laroza-tv.lat/home.24 on launch (after profile/PIN gating).
- Existing Luna HTML5 fullscreen video controls, remote controls, popup guards and adblock lists are retained.

Important:
- This is source code, not a compiled APK.
- The original project already contains fullscreen controls for HTML5 video and ad/pop-up blocking.
- Fullscreen/landscape behavior depends on the website's player and Android WebView; embedded or DRM/proprietary players may behave differently.
- No claim that every ad is blocked: first-party/server-inserted ads can remain.
- Build with Android Studio, JDK 17, Android SDK 36, and network access to download Gradle dependencies.
- Open the project folder in Android Studio and build the `app` release variant.


Compatibility adjustment (2026-11-26): minSdk lowered from 26 to 25 for devices reporting Android API 25 (Android 7.1). This only permits installation at the manifest level; runtime compatibility still needs testing on the target TV box. The device reports Android 14 but CPU-Z reports API 25, so the API level is the relevant install requirement.
